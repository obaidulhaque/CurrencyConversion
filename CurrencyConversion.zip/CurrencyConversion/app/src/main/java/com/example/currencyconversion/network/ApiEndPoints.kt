package com.example.currencyconversion.network


object ApiEndPoints {
    const val LIST = "list"
    const val LIVE = "live"
}