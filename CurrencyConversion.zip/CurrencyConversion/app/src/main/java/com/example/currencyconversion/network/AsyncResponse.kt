package com.example.currencyconversion.network

interface AsyncResponse {

    fun processFinish(output: String?)
}