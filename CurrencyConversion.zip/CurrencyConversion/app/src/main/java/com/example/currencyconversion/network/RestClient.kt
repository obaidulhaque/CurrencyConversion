package com.example.currencyconversion.network

import android.os.AsyncTask
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response


object RestClient {

    var delegate: AsyncResponse? = null

    fun snedLiveRequest(value: String) {

        val obj = FeedTask()
        obj.execute(NetworkConstants.BASE_URL + ApiEndPoints.LIVE + "?access_key=" + NetworkConstants.ACCESS_KEY + "&source=" + value)
    }

    fun sendListRequest() {

        val obj = FeedTask()
        obj.execute(NetworkConstants.BASE_URL + ApiEndPoints.LIST + "?access_key=" + NetworkConstants.ACCESS_KEY)
    }

    private class FeedTask : AsyncTask<String, Void, String>() {
        /*
        override fun onPreExecute() {

        }
         */

        override fun doInBackground(vararg params: String): String {

            val client: OkHttpClient = OkHttpClient()
            val request: Request = Request.Builder()
                .url(params[0])
                .build()
            val response: Response = client.newCall(request).execute()
            var result: String? = null
            result = response.body?.string()
            return result.toString()
        }

        /*
        override fun onProgressUpdate(vararg values: Int?) {

        }*/

        override fun onPostExecute(result: String) {

            delegate?.processFinish(result)
        }
    }

}