package com.example.currencyconversion.model

data class ExchangeRate(
    var key: String?,
    var value: Double?
)