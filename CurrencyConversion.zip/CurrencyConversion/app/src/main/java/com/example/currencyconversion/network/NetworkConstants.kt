package com.example.currencyconversion.network

object NetworkConstants {
    const val ACCESS_KEY = "e64cd01cf34a9ef459c2922c5565acf1"
    const val BASE_URL = "http://api.currencylayer.com/"
}