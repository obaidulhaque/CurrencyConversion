package com.example.currencyconversion

import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.text.isDigitsOnly
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.currencyconversion.callbacks.ItemSelectedListener
import com.example.currencyconversion.model.ExchangeRate
import com.example.currencyconversion.model.ExchangeRateAdapter
import com.example.currencyconversion.network.AsyncResponse
import com.example.currencyconversion.network.RestClient
import kotlinx.android.synthetic.main.activity_main.*


class MainActivity : AppCompatActivity(), AsyncResponse {

    private var flag: Int? = null
    private var source: String? = null
    private lateinit var adapter: ExchangeRateAdapter
    private var amt: Int = 1

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // web service call: LIST Request
        flag = 0
        RestClient.delegate = this
        RestClient.sendListRequest()

        setListeners()
    }

    private fun setListeners() {

        spinner.onItemSelectedListener = object : ItemSelectedListener() {
            var count = 0
            override fun onItemSelected(p0: AdapterView<*>?, p1: View?, p2: Int, p3: Long) {

                if (count >= 1)
                {
                    flag = 1
                    source = p0?.selectedItem.toString()
                    RestClient.snedLiveRequest(source!!)
                }
                count += 1
            }
        }

        currency.addTextChangedListener(object : TextWatcher {
            override fun onTextChanged(
                s: CharSequence,
                start: Int,
                before: Int,
                count: Int
            ) {
                val number = currency.text.toString().toIntOrNull()
                val isInteger = number != null
                if( isInteger && currency.text.toString().toDouble() <= 0)
                {
                    Toast.makeText(this@MainActivity, "Invalid Number. Please enter valid number", Toast.LENGTH_SHORT).show()
                }
            }

            override fun beforeTextChanged(
                s: CharSequence,
                start: Int,
                count: Int,
                after: Int
            ) { // TODO Auto-generated method stub
            }

            override fun afterTextChanged(s: Editable) {

                if(currency.length() > 0 && !currency.equals("") )
                {
                    amt = currency.text.toString().toInt()
                }
                else
                {
                    val list = ArrayList<ExchangeRate>()
                    showAdapterData(list)
                }
            }
        })
    }

    override fun processFinish(output: String?) {

        val idx = output?.indexOf("success")
        val isSuccess: Boolean = output?.substring(idx!! + 9, idx + 13)!!.toBoolean()
        if (isSuccess == false)
        {
            val idx = output?.indexOf("info")
            var msg = output?.substring(idx!! + 7)
            msg = msg.substring(0, msg.length - 3)
            Toast.makeText(this, msg, Toast.LENGTH_LONG).show()
            val list = ArrayList<ExchangeRate>()
            showAdapterData(list)
            return
        }

        when(flag) {
            0 -> processListRequest(output)
            else -> processLiveRequest(output)
        }
    }

    private fun processLiveRequest(output: String?) {

        val list = ArrayList<ExchangeRate>()
        val idx = output!!.indexOf("quotes")
        var res: String = output!!.substring(idx + 9)
        val size = res.length
        res = res.substring(0, size -2)
        val map = res.split(",").associate {
            var (left, right) = it.split(":")

            if (left.length > 0) {
                left = left.substring(1, left.length - 1)
                left = left.replace(source!!, "")
            }

            val item = ExchangeRate(left, right.toDouble()*amt)
            list += item
            left to right.toString()
        }

        showAdapterData(list)
    }

    private fun processListRequest(output: String?){

        val idx = output?.indexOf("currencies")
        val res: String = output!!.substring(idx!! + 13)

        val map = res.split(",").associate {
            var (left, right) = it.split(":")
            left = left.substring(1, left.length - 1)
            right = right.substring(1, right.length - 1)
            left to right.toString()
        }

        val finalRessult = ArrayList(map.keys)
        val adapter = ArrayAdapter<String>(
            this@MainActivity,
            android.R.layout.simple_spinner_dropdown_item, finalRessult
        )

        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        spinner.setAdapter(adapter)
    }

    private fun showAdapterData(list:  ArrayList<ExchangeRate>)
    {
        exchangeRateList.layoutManager = LinearLayoutManager(this)
        adapter = ExchangeRateAdapter(this, list)
        exchangeRateList.adapter = adapter
        exchangeRateList.setHasFixedSize(true)
    }


}
